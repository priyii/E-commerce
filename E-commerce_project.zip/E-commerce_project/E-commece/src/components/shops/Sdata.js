const Sdata = {
  shopItems: [
    {
      id: 7,
      cover: "./images/SlideCard/slide-3.png",
      name: "Puma Jacket",
      price: "1500",
    },
    {
      id: 8,
      cover: "./images/SlideCard/slide-3.png",
      name: "Zara Jacket",
      price: "1320",
    },
    {
      id: 9,
      cover: "./images/SlideCard/slide-3.png",
      name: "Nike Jacket",
      price: "1200",
    },
    
    
  ],
}
export default Sdata
